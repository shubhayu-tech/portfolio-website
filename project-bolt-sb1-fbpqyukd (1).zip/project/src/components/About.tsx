import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Brain, Database } from 'lucide-react';
import Spline from '@splinetool/react-spline';

export default function About() {
  return (
    <section id="about" className="relative min-h-screen py-20 px-4">
      {/* Spline 3D Background */}
      <div className="absolute inset-0 z-0">
        <div className="spline-scene">
          <Spline scene="https://prod.spline.design/5LbBhQ0sdaCSPtKo/scene.splinecode" />
        </div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">About Me</h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            I'm a CSE student specializing in AI, passionate about creating innovative solutions 
            and exploring the intersection of artificial intelligence and web development.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="bg-secondary-dark/30 backdrop-blur-sm p-4 rounded-lg"
          >
            <img
              src="https://images.unsplash.com/photo-1549692520-acc6669e2f0c"
              alt="Profile"
              className="rounded-lg shadow-xl"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6 bg-secondary-dark/30 backdrop-blur-sm p-6 rounded-lg"
          >
            <div className="space-y-4">
              <h3 className="text-2xl font-semibold mb-4">What I Do</h3>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <Code2 className="text-accent" size={24} />
                  <div>
                    <h4 className="font-semibold">Web Development</h4>
                    <p className="text-gray-300">Building responsive and modern web applications</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Brain className="text-accent" size={24} />
                  <div>
                    <h4 className="font-semibold">AI & Machine Learning</h4>
                    <p className="text-gray-300">Exploring AI applications and algorithms</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <Database className="text-accent" size={24} />
                  <div>
                    <h4 className="font-semibold">Backend Development</h4>
                    <p className="text-gray-300">Creating robust server-side solutions</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}