import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Github, Linkedin, Instagram } from 'lucide-react';
import Spline from '@splinetool/react-spline';

export default function Contact() {
  return (
    <section id="contact" className="relative min-h-screen py-20 px-4">
      {/* Spline 3D Background */}
      <div className="absolute inset-0 z-0">
        <Spline scene="https://prod.spline.design/D5OiCorfpQ2auCbH/scene.splinecode" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Get in Touch</h2>
          <p className="text-xl text-gray-300">Let's work together on something great</p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8 bg-secondary-dark/30 backdrop-blur-sm p-6 rounded-lg"
          >
            <div className="flex items-start gap-4">
              <Mail className="text-accent" size={24} />
              <div>
                <h3 className="font-semibold mb-1">Email</h3>
                <a href="mailto:shubhayuchakraborty69@gmail.com" className="text-gray-300 hover:text-accent transition-colors">
                  shubhayuchakraborty69@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Github className="text-accent" size={24} />
              <div>
                <h3 className="font-semibold mb-1">GitHub</h3>
                <a href="https://github.com/shubhayu-tech" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-accent transition-colors">
                  github.com/shubhayu-tech
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Linkedin className="text-accent" size={24} />
              <div>
                <h3 className="font-semibold mb-1">LinkedIn</h3>
                <a href="https://www.linkedin.com/in/shubhayu-chakraborty-b23855280" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-accent transition-colors">
                  Shubhayu Chakraborty
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <Instagram className="text-accent" size={24} />
              <div>
                <h3 className="font-semibold mb-1">Instagram</h3>
                <a href="https://www.instagram.com/ms7shubhayu/profilecard" target="_blank" rel="noopener noreferrer" className="text-gray-300 hover:text-accent transition-colors">
                  @ms7shubhayu
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <MapPin className="text-accent" size={24} />
              <div>
                <h3 className="font-semibold mb-1">Location</h3>
                <p className="text-gray-300">Kolkata, India</p>
              </div>
            </div>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6 bg-secondary-dark/30 backdrop-blur-sm p-6 rounded-lg"
          >
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-2">Name</label>
              <input
                type="text"
                id="name"
                className="w-full px-4 py-2 bg-secondary-dark rounded-lg focus:ring-2 focus:ring-accent focus:outline-none"
                placeholder="Your name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-2">Email</label>
              <input
                type="email"
                id="email"
                className="w-full px-4 py-2 bg-secondary-dark rounded-lg focus:ring-2 focus:ring-accent focus:outline-none"
                placeholder="your.email@example.com"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium mb-2">Message</label>
              <textarea
                id="message"
                rows={4}
                className="w-full px-4 py-2 bg-secondary-dark rounded-lg focus:ring-2 focus:ring-accent focus:outline-none"
                placeholder="Your message"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full px-6 py-3 bg-primary hover:bg-primary-light text-white rounded-lg transition-colors duration-300"
            >
              Send Message
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
}