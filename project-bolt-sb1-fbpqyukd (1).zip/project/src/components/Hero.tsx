import React from 'react';
import { motion } from 'framer-motion';
import Typewriter from 'typewriter-effect';
import { ChevronDown, Github, Linkedin, Mail, Instagram } from 'lucide-react';
import Spline from '@splinetool/react-spline';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Spline 3D Background */}
      <div className="absolute inset-0 z-0">
        <div className="spline-scene">
          <Spline scene="https://prod.spline.design/yvRGpisemhOz0BpV/scene.splinecode" />
        </div>
      </div>

      {/* Content Overlay */}
      <div className="relative z-10 text-center px-4 bg-secondary-dark/30 backdrop-blur-sm rounded-lg p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Hi, I'm{' '}
            <span className="bg-gradient-to-r from-primary-light to-accent bg-clip-text text-transparent">
              Shubhayu Chakraborty
            </span>
          </h1>

          <div className="text-xl md:text-2xl text-gray-300 h-20">
            <Typewriter
              options={{
                strings: [
                  'CSE AI Student',
                  'Web Developer',
                  'Problem Solver'
                ],
                autoStart: true,
                loop: true,
                deleteSpeed: 50,
                delay: 80
              }}
            />
          </div>

          <div className="flex justify-center gap-4 mt-8">
            <motion.a
              href="#projects"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 bg-primary hover:bg-primary-light text-white rounded-full font-medium transition-colors duration-300"
            >
              Explore My Work
            </motion.a>
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 border border-primary hover:border-primary-light text-white rounded-full font-medium transition-colors duration-300"
            >
              Get in Touch
            </motion.a>
          </div>

          <div className="flex justify-center gap-6 mt-12">
            <motion.a
              href="https://github.com/shubhayu-tech"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.1, y: -2 }}
              className="text-gray-400 hover:text-accent transition-colors duration-300"
            >
              <Github size={24} />
            </motion.a>
            <motion.a
              href="https://www.linkedin.com/in/shubhayu-chakraborty-b23855280"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.1, y: -2 }}
              className="text-gray-400 hover:text-accent transition-colors duration-300"
            >
              <Linkedin size={24} />
            </motion.a>
            <motion.a
              href="https://www.instagram.com/ms7shubhayu/profilecard"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.1, y: -2 }}
              className="text-gray-400 hover:text-accent transition-colors duration-300"
            >
              <Instagram size={24} />
            </motion.a>
            <motion.a
              href="mailto:shubhayuchakraborty69@gmail.com"
              whileHover={{ scale: 1.1, y: -2 }}
              className="text-gray-400 hover:text-accent transition-colors duration-300"
            >
              <Mail size={24} />
            </motion.a>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{
          duration: 1,
          repeat: Infinity,
          repeatType: "reverse"
        }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <ChevronDown className="w-8 h-8 text-accent animate-bounce" />
      </motion.div>
    </section>
  );
}