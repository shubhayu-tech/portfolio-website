import React from 'react';
import { motion } from 'framer-motion';
import { Code, Database, Brain, Globe, Server, Terminal } from 'lucide-react';
import Spline from '@splinetool/react-spline';

const skills = [
  {
    category: "Frontend",
    icon: <Code size={24} />,
    items: ["HTML", "CSS", "JavaScript", "React", "TypeScript"]
  },
  {
    category: "Backend",
    icon: <Server size={24} />,
    items: ["Node.js", "Python", "SQL", "REST APIs"]
  },
  {
    category: "AI/ML",
    icon: <Brain size={24} />,
    items: ["TensorFlow", "PyTorch", "Scikit-learn", "Computer Vision"]
  },
  {
    category: "Tools",
    icon: <Terminal size={24} />,
    items: ["Git", "Docker", "AWS", "Linux"]
  }
];

export default function Skills() {
  return (
    <section id="skills" className="relative min-h-screen py-20 px-4 overflow-hidden">
      {/* Spline 3D Background */}
      <div className="absolute inset-0 z-0">
        <Spline scene="https://prod.spline.design/yGkU3se6259w9Vp1/scene.splinecode" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Skills</h2>
          <p className="text-xl text-gray-300">My technical expertise and tools I work with</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-secondary-dark/80 backdrop-blur-md p-6 rounded-lg shadow-lg hover:shadow-accent/10 transition-shadow"
            >
              <div className="flex items-center gap-3 mb-4">
                <span className="text-accent">{skill.icon}</span>
                <h3 className="text-xl font-semibold">{skill.category}</h3>
              </div>
              <ul className="space-y-2">
                {skill.items.map((item) => (
                  <li key={item} className="text-gray-300">{item}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}